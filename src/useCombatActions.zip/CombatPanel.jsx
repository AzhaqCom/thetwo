import React, { useCallback } from 'react';
import { useCombatManager } from './CombatManager';
import { useCombatActions } from './CombatActions';
import { useCombatActionHandler } from './CombatActionHandler';
import CombatTurnManager from './CombatTurnManager';
import CombatGrid from './CombatGrid';
import PlayerTurnPanel from './PlayerTurnPanel';
import CombatLog from '../ui/CombatLog';

const CombatPanel = ({
    playerCharacter,
    playerCompanion,
    onCombatEnd,
    addCombatMessage,
    combatLog,
    setCombatLog,
    encounterData,
    onPlayerCastSpell,
    onPlayerTakeDamage,
    onReplayCombat,
    combatKey,
    onCompanionTakeDamage
}) => {
    // Use combat manager hook
    const combatManager = useCombatManager({
        playerCharacter,
        playerCompanion,
        encounterData,
        addCombatMessage,
        onPlayerTakeDamage,
        onCompanionTakeDamage,
        combatKey
    });

    // Use combat actions hook
    const { enemyAttack, companionAttack } = useCombatActions({
        playerCharacter,
        companionCharacter: combatManager.companionCharacter,
        combatEnemies: combatManager.combatEnemies,
        setCombatEnemies: combatManager.setCombatEnemies,
        turnOrder: combatManager.turnOrder,
        currentTurnIndex: combatManager.currentTurnIndex,
        combatPositions: combatManager.combatPositions,
        onPlayerTakeDamage,
        onCompanionTakeDamage,
        handleNextTurn: combatManager.handleNextTurn,
        updateEnemyPosition: combatManager.updateEnemyPosition,
        calculateEnemyMovementPosition: combatManager.calculateEnemyMovementPosition,
        addCombatMessage
    });

    // Use action handler hook
    const { handleExecuteAction } = useCombatActionHandler({
        playerCharacter,
        playerAction: combatManager.playerAction,
        actionTargets: combatManager.actionTargets,
        setPlayerAction: combatManager.setPlayerAction,
        setActionTargets: combatManager.setActionTargets,
        setSelectedAoESquares: combatManager.setSelectedAoESquares,
        setAoECenter: combatManager.setAoECenter,
        setShowTargetingFor: combatManager.setShowTargetingFor,
        combatEnemies: combatManager.combatEnemies,
        setCombatEnemies: combatManager.setCombatEnemies,
        combatPositions: combatManager.combatPositions,
        setCombatPositions: combatManager.setCombatPositions,
        onPlayerCastSpell,
        addCombatMessage,
        handleNextTurn: combatManager.handleNextTurn
    });

    const handlePlayerMoveCharacter = useCallback((characterId, newPosition) => {
        combatManager.handleMoveCharacter(characterId, newPosition);
        combatManager.setCombatPhase('player-action');
    }, [combatManager]);
    
    const findCharacterAtPosition = useCallback((x, y) => {
        // Check player
        if (combatManager.combatPositions.player && combatManager.combatPositions.player.x === x && combatManager.combatPositions.player.y === y) {
            return { ...playerCharacter, id: 'player', name: playerCharacter.name };
        }

        // Check companion
        if (combatManager.combatPositions.companion && combatManager.combatPositions.companion.x === x && combatManager.combatPositions.companion.y === y && combatManager.companionCharacter) {
            return { ...combatManager.companionCharacter, id: 'companion', name: combatManager.companionCharacter.name };
        }

        // Check enemies
        for (const enemy of combatManager.combatEnemies) {
            const enemyPos = combatManager.combatPositions[enemy.name];
            if (enemyPos && enemyPos.x === x && enemyPos.y === y) {
                return enemy;
            }
        }

        return null;
    }, [combatManager.combatPositions, playerCharacter, combatManager.companionCharacter, combatManager.combatEnemies]);

    const calculateAoESquares = useCallback((center, aoeType) => {
        const squares = [];

        switch (aoeType.shape) {
            case 'sphere':
                const radius = Math.floor(aoeType.radius / 5); // Convert feet to squares
                for (let x = center.x - radius; x <= center.x + radius; x++) {
                    for (let y = center.y - radius; y <= center.y + radius; y++) {
                        if (x >= 0 && x < 8 && y >= 0 && y < 6) {
                            const distance = Math.sqrt(Math.pow(x - center.x, 2) + Math.pow(y - center.y, 2));
                            if (distance <= radius) {
                                squares.push({ x, y });
                            }
                        }
                    }
                }
                break;
            case 'cube':
                const size = Math.floor(aoeType.size / 5); // Convert feet to squares
                for (let x = center.x; x < center.x + size && x < 8; x++) {
                    for (let y = center.y; y < center.y + size && y < 6; y++) {
                        if (x >= 0 && y >= 0) {
                            squares.push({ x, y });
                        }
                    }
                }
                break;
        }

        return squares;
    }, []);

    const handleTargetSelection = useCallback(
        (enemy) => {
          

            if (combatManager.playerAction?.areaOfEffect) {
            
                // Handle AoE spell targeting
                const centerPos = enemy.isPosition ? { x: enemy.x, y: enemy.y } : combatManager.combatPositions[enemy.name];
                if (centerPos) {
                  
                    combatManager.setAoECenter(centerPos);
                    const affectedSquares = calculateAoESquares(centerPos, combatManager.playerAction.areaOfEffect);
                  
                    combatManager.setSelectedAoESquares(affectedSquares);

                    // Find all targets in affected squares
                    const targets = [];
                    affectedSquares.forEach(square => {
                        const targetAtSquare = findCharacterAtPosition(square.x, square.y);
                        if (targetAtSquare && targetAtSquare.currentHP > 0 && targetAtSquare.type === 'enemy') {
                            targets.push(targetAtSquare);
                        }
                    });

                   
                    handleExecuteAction(targets); // Pass targets directly
                }
            } else {
 
                const maxTargets = combatManager.playerAction?.projectiles || 1;
               

                // For single target spells, we need to find the actual enemy at the position
                let actualTarget = enemy;
                if (enemy.isPosition) {
                    actualTarget = findCharacterAtPosition(enemy.x, enemy.y);
                    if (!actualTarget || actualTarget.type !== 'enemy' || actualTarget.currentHP <= 0) {
                        addCombatMessage("Aucune cible valide à cette position.", 'miss');
                        return;
                    }
                }

                const newTargets = [...combatManager.actionTargets, actualTarget];
              
                combatManager.setActionTargets(newTargets);

                // Auto-execute when we have enough targets
                if (newTargets.length >= maxTargets) {
                    setTimeout(() => {
                        handleExecuteAction(newTargets);
                    }, 100);
                }
            }
        },
        [combatManager, findCharacterAtPosition, handleExecuteAction, addCombatMessage, calculateAoESquares]
    );



    const findPositionByCharacter = useCallback((character) => {
        if (character.id === 'player') return combatManager.combatPositions.player;
        if (character.id === 'companion') return combatManager.combatPositions.companion;
        return combatManager.combatPositions[character.name];
    }, [combatManager.combatPositions]);

    // Render different phases
    const renderCombatPhase = () => {
        switch (combatManager.combatPhase) {
            case 'initializing':
                return (
                    <div className="combat-controls">
                        <p>Initialisation du combat...</p>
                    </div>
                );

            case 'initiative-display':
                return (
                    <div className="combat-controls">
                        <p>Les jets d'initiative ont été lancés. Clique pour commencer le combat !</p>
                        <button onClick={combatManager.startCombat}>
                            Commencer le combat
                        </button>
                    </div>
                );

            case 'player-movement':
                return (
                    <div className="combat-controls">
                        <h3>Phase de Mouvement</h3>
                        <p>Clique sur une case verte pour te déplacer (6 cases maximum).</p>
                        <button className='action-button movement' onClick={() => {
                            combatManager.setShowMovementFor(null);
                            combatManager.setCombatPhase('player-action');
                        }}>
                            Passer le mouvement
                        </button>
                    </div>
                );

            case 'player-action':
                return (
                    <PlayerTurnPanel
                        playerCharacter={playerCharacter}
                        onSelectAction={(action) => {
                            combatManager.setPlayerAction(action);
                            combatManager.setShowTargetingFor('player');
                        }}
                        onPassTurn={() => {
                            combatManager.setPlayerAction(null);
                            combatManager.setShowTargetingFor(null);
                            combatManager.handleNextTurn();
                        }}
                        selectedAction={combatManager.playerAction}
                        selectedTargets={combatManager.actionTargets}
                    />
                );

            case 'end':
                return (
                    <div className="combat-controls">
                        <h3>Combat terminé !</h3>
                        {combatManager.victory && (
                            <button onClick={() => {
                                setCombatLog([]);
                                onCombatEnd(encounterData);
                            }}>
                                Continuer l'aventure
                            </button>
                        )}
                        {combatManager.defeated && (
                            <>
                                <p>Tu as été vaincu. Tu peux rejouer le combat ou continuer l'aventure.</p>
                                <button onClick={onReplayCombat} style={{ marginTop: '10px' }}>
                                    Rejouer le combat
                                </button>
                            </>
                        )}
                    </div>
                );

            case 'turn':
            case 'executing-turn':
            default:
                return (
                    <div className="combat-controls">
                        <p>Le combat est en cours...</p>
                    </div>
                );
        }
    };

    return (
        <div className="combat-interface">
            {/* Turn Manager - handles automatic turn progression */}
            <CombatTurnManager
                combatPhase={combatManager.combatPhase}
                setCombatPhase={combatManager.setCombatPhase}
                turnOrder={combatManager.turnOrder}
                currentTurnIndex={combatManager.currentTurnIndex}
                playerCharacter={playerCharacter}
                companionCharacter={combatManager.companionCharacter}
                combatEnemies={combatManager.combatEnemies}
                handleNextTurn={combatManager.handleNextTurn}
                addCombatMessage={addCombatMessage}
                setShowMovementFor={combatManager.setShowMovementFor}
                enemyAttack={enemyAttack}
                companionAttack={companionAttack}
            />

            {/* Combat Grid Container - 60% width */}
            {combatManager.isInitialized && (
                <CombatGrid
                    playerCharacter={playerCharacter}
                    playerCompanion={combatManager.companionCharacter}
                    combatEnemies={combatManager.combatEnemies}
                    onSelectTarget={handleTargetSelection}
                    selectedTargets={combatManager.actionTargets}
                    currentTurnIndex={combatManager.currentTurnIndex}
                    turnOrder={combatManager.turnOrder}
                    onMoveCharacter={combatManager.handleMoveCharacter}
                    combatPositions={combatManager.combatPositions}
                    showMovementFor={combatManager.showMovementFor}
                    showTargetingFor={combatManager.showTargetingFor}
                    selectedAoESquares={combatManager.selectedAoESquares}
                    aoeCenter={combatManager.aoeCenter}
                />
            )}

            {/* Combat Side Container - 40% width */}
            <div className="combat-side-container">
                {/* Phase-specific controls */}

                {renderCombatPhase()}


                {/* Combat Log */}
                <div className="combat-log-container">
                    <CombatLog logMessages={combatLog} />
                </div>
            </div>
        </div>
    );
};

export default CombatPanel;