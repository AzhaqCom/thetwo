import React, { useState, useEffect, useCallback } from 'react';
import { enemyTemplates } from '../data/enemies';
import { spells } from '../data/spells';

const rollDice = (diceString) => {
    if (!diceString || !diceString.includes('d')) return 0;
    const [num, size] = diceString.split('d').map(Number);
    let totalDamage = 0;
    for (let i = 0; i < num; i++) {
        totalDamage += Math.floor(Math.random() * size) + 1;
    }
    return totalDamage;
};

const Combat = ({ playerCharacter, setPlayerCharacter, onCombatEnd, addCombatMessage, setCombatLog, encounterData }) => {
    const [combatEnemies, setCombatEnemies] = useState([]);
    const [turnOrder, setTurnOrder] = useState([]);
    const [currentTurnIndex, setCurrentTurnIndex] = useState(0);
    const [combatPhase, setCombatPhase] = useState('initiative-roll');
    const [playerAction, setPlayerAction] = useState(null);
    const [actionTargets, setActionTargets] = useState([]);

    const handleNextTurn = useCallback(() => {
        const allEnemiesDefeated = combatEnemies.every(enemy => enemy.hp <= 0);
        if (allEnemiesDefeated) {
            setCombatPhase('end');
            addCombatMessage("Victoire ! Les ennemis sont vaincus.");
            return;
        }
        
        if (playerCharacter.currentHP <= 0) {
            setCombatPhase('end');
            addCombatMessage("Défaite... Tu as perdu connaissance.");
            return;
        }

        const nextIndex = (currentTurnIndex + 1) % turnOrder.length;
        setCurrentTurnIndex(nextIndex);
        setCombatPhase('turn');
    }, [currentTurnIndex, turnOrder, combatEnemies, addCombatMessage, playerCharacter.currentHP]);


    const enemyAttack = useCallback(() => {
        const currentTurnEntity = turnOrder[currentTurnIndex];
        
        // CORRECTION: Double-vérification que l'entité est vivante juste avant d'attaquer.
        const isAliveInState = combatEnemies.find(e => e.name === currentTurnEntity.name)?.hp > 0;
        if (!isAliveInState) {
            addCombatMessage(`${currentTurnEntity.name} est déjà vaincu et ne peut pas attaquer.`);
            handleNextTurn();
            return;
        }
        
        const enemyAttackRoll = Math.floor(Math.random() * 20) + 1;
        const playerAC = playerCharacter.ac; 
        
        if (enemyAttackRoll >= playerAC) {
            const damage = rollDice(currentTurnEntity.damageDice);
            setPlayerCharacter(prev => {
                const newHP = Math.max(0, prev.currentHP - damage);
                addCombatMessage(`${currentTurnEntity.name} t'attaque et touche ! Il inflige ${damage} dégâts !`);
                return { ...prev, currentHP: newHP };
            });
        } else {
            addCombatMessage(`${currentTurnEntity.name} t'attaque, mais rate son coup.`);
        }
        handleNextTurn();
    }, [addCombatMessage, handleNextTurn, setPlayerCharacter, playerCharacter.ac, turnOrder, currentTurnIndex, combatEnemies]);

    const castSpell = useCallback((spell, targets) => {
        if (spell.level > 0) {
            const spellSlots = playerCharacter.spellcasting.spellSlots[spell.level];
            if (spellSlots && spellSlots.used < spellSlots.total) {
                setPlayerCharacter(prev => {
                    const newSlots = {
                        ...prev.spellcasting.spellSlots,
                        [spell.level]: { ...spellSlots, used: spellSlots.used + 1 }
                    };
                    return { ...prev, spellcasting: { ...prev.spellcasting, spellSlots: newSlots } };
                });
            } else {
                addCombatMessage(`Tu n'as plus d'emplacement de sort de niveau ${spell.level} disponible.`);
                setPlayerAction(null);
                setActionTargets([]);
                return;
            }
        }

        let updatedEnemies = [...combatEnemies];
        
        const defeatedThisTurn = new Set();
        
        targets.forEach(target => {
            const enemyIndex = updatedEnemies.findIndex(e => e.name === target.name);
            if (enemyIndex !== -1 && updatedEnemies[enemyIndex].hp > 0) {
                let damage = 0;
                
                if (spell.requiresAttackRoll) {
                    const spellAttackBonus = playerCharacter.proficiencyBonus + Math.floor((playerCharacter.stats.intelligence - 10) / 2);
                    const attackRoll = Math.floor(Math.random() * 20) + 1 + spellAttackBonus;
                    
                    if (attackRoll >= updatedEnemies[enemyIndex].ac) {
                        damage = rollDice(spell.damage.dice) + (spell.damage.bonus || 0);
                        updatedEnemies[enemyIndex].hp = Math.max(0, updatedEnemies[enemyIndex].hp - damage);
                        addCombatMessage(`Le sort "${spell.name}" touche ${target.name} (Jet d'attaque: ${attackRoll}) et inflige ${damage} dégâts de ${spell.damage.type} !`);
                    } else {
                        addCombatMessage(`Le sort "${spell.name}" rate ${target.name} (Jet d'attaque: ${attackRoll}).`);
                    }
                } else {
                    damage = rollDice(spell.damage.dice) + (spell.damage.bonus || 0);
                    updatedEnemies[enemyIndex].hp = Math.max(0, updatedEnemies[enemyIndex].hp - damage);
                    addCombatMessage(`Le sort "${spell.name}" frappe ${target.name} et inflige ${damage} dégâts de ${spell.damage.type} !`);
                }

                if (updatedEnemies[enemyIndex].hp <= 0 && !defeatedThisTurn.has(updatedEnemies[enemyIndex].name)) {
                    addCombatMessage(`${updatedEnemies[enemyIndex].name} a été vaincu !`);
                    defeatedThisTurn.add(updatedEnemies[enemyIndex].name);
                }
            }
        });

        setCombatEnemies(updatedEnemies);
        setPlayerAction(null);
        setActionTargets([]);
        handleNextTurn();
    }, [playerCharacter, addCombatMessage, handleNextTurn, combatEnemies]);

    useEffect(() => {
        const initialCombatEnemies = encounterData.flatMap(encounter => {
            const template = enemyTemplates[encounter.type];
            if (!template) {
                console.error(`Erreur: Template de monstre '${encounter.type}' non trouvé.`);
                return [];
            }
            return Array(encounter.count).fill(null).map((_, index) => ({
                ...template,
                name: `${template.name} ${index + 1}`
            }));
        });

        if (!initialCombatEnemies || initialCombatEnemies.length === 0) {
            console.error("Erreur: La liste d'ennemis est vide. Le combat se termine.");
            addCombatMessage("Erreur lors du chargement des ennemis. Le combat se termine.");
            setCombatPhase('end');
            return;
        }

        setCombatEnemies(initialCombatEnemies);
        addCombatMessage("Un combat commence !");

        const playerDexMod = Math.floor((playerCharacter.stats.dexterite - 10) / 2);
        const playerInitiative = Math.floor(Math.random() * 20) + 1 + playerDexMod;
        const playerWithInitiative = { ...playerCharacter, initiative: playerInitiative, type: 'player', ac: 10 };

        const enemiesWithInitiative = initialCombatEnemies.map(enemy => ({
            ...enemy,
            initiative: Math.floor(Math.random() * 20) + 1 + Math.floor((enemy.dex - 10) / 2),
            type: 'enemy'
        }));

        const order = [...enemiesWithInitiative, playerWithInitiative].sort((a, b) => b.initiative - a.initiative);
        setTurnOrder(order);

        order.forEach(entity => {
            addCombatMessage(`${entity.name} a lancé l'initiative et a obtenu ${entity.initiative}.`);
        });

    }, [encounterData, playerCharacter.stats.dexterite, addCombatMessage]);
    
    useEffect(() => {
        if (combatPhase === 'initiative-roll' || combatPhase === 'end' || !turnOrder.length) {
            return;
        }

        const currentTurnEntity = turnOrder[currentTurnIndex];
        const isPlayerTurn = currentTurnEntity.type === 'player';
        
        // CORRECTION MAJEURE: on vérifie l'état de l'entité dans l'état actuel (combatEnemies) et non pas celui de la turnOrder initiale.
        const entityInState = combatEnemies.find(e => e.name === currentTurnEntity.name);

        if (entityInState && entityInState.hp <= 0) {
            addCombatMessage(`${currentTurnEntity.name} est déjà vaincu. On passe au suivant.`);
            handleNextTurn();
            return;
        }
        
        if (combatPhase === 'turn') {
            if (isPlayerTurn) {
                setCombatPhase('player-action');
                addCombatMessage("C'est ton tour !");
            } else {
                addCombatMessage(`C'est le tour de ${currentTurnEntity.name}...`);
                const timer = setTimeout(() => {
                    enemyAttack();
                }, 1500);
                return () => clearTimeout(timer);
            }
        }

    }, [currentTurnIndex, combatPhase, turnOrder, addCombatMessage, enemyAttack, combatEnemies]);

    if (combatPhase === 'initiative-roll') {
        return (
            <div>
                <p>Les jets d'initiative ont été lancés. Clique pour commencer le combat !</p>
                <button onClick={() => setCombatPhase('turn')}>Commencer le combat</button>
            </div>
        );
    }

    if (combatPhase === 'end') {
        return (
            <div>
                <h3>Combat terminé !</h3>
                 <button onClick={() => {
                    setCombatLog([]); 
                    onCombatEnd(); 
                }}>Continuer l'aventure</button>
            </div>
        );
    }
    
    if (combatPhase === 'player-action' && !playerAction) {
        const offensiveSpells = [...playerCharacter.spellcasting.cantrips, ...playerCharacter.spellcasting.preparedSpells]
            .map(spellName => spells[spellName])
            .filter(spell => spell && spell.damage);

        const aliveEnemies = combatEnemies.filter(e => e.hp > 0);
        
        if (aliveEnemies.length === 0) {
            handleNextTurn();
            return null;
        }

        return (
            <div>
                <p>C'est ton tour ! Quel sort veux-tu lancer ?</p>
                {offensiveSpells.map(spell => (
                    <button key={spell.name} onClick={() => setPlayerAction(spell)}>
                        {spell.name}
                        {spell.level > 0 && ` (Niv. ${spell.level})`}
                    </button>
                ))}
                <button onClick={() => { setPlayerAction(null); handleNextTurn(); }}>Passer le tour</button>
            </div>
        );
    }

    if (combatPhase === 'player-action' && playerAction) {
        const maxTargets = playerAction.projectiles || 1;
        const aliveEnemies = combatEnemies.filter(e => e.hp > 0);

        const handleTargetSelection = (enemy) => {
            const newTargets = [...actionTargets, enemy];
            if (newTargets.length === maxTargets) {
                castSpell(playerAction, newTargets);
            } else {
                setActionTargets(newTargets);
            }
        };

         return (
            <div>
                <p>Choisis la cible n°{actionTargets.length + 1} de ton sort ({actionTargets.length + 1}/{maxTargets}) :</p>
                {/* MODIFICATION ICI */}
                {aliveEnemies.map(enemy => (
                    <button key={enemy.name} onClick={() => handleTargetSelection(enemy)}>
                        <img src={enemy.image} alt={enemy.name} style={{ width: '50px', height: '50px', marginRight: '10px' }} />
                        {enemy.name} (PV: {enemy.hp})
                    </button>
                ))}
            </div>
        );
    }

    return (
        <div>
            <p>Le combat est en cours...</p>
        </div>
    );
};

export default Combat;