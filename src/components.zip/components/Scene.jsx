import React from 'react';

const Scene = ({ text, choices, onChoice }) => {
    return (
        <div className="scene">
            <p>{text}</p>
            {choices && choices.map((choice, index) => (
                <button
                    key={index}
                    onClick={() => {
                        if (choice.next) {
                            onChoice(choice.next);
                        } else if (choice.action) {
                            onChoice(choice.action);
                        }
                    }}
                >
                    {choice.text}
                </button>
            ))}
        </div>
    );
};

export default Scene;