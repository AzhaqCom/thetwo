import React, { useEffect, useRef, forwardRef } from 'react';

const CombatLog = (props) => {
    const logRef = useRef(null);

    useEffect(() => {
        if (logRef.current) {
            logRef.current.scrollTop = logRef.current.scrollHeight;
        }
    }, [props.logMessages]);

    return (
        <div id="combat-log" style={{ display: props.logMessages.length > 0 ? 'block' : 'none' }}>
            <strong>Journal :</strong>
            <div id="log-entries" ref={logRef}>
                {props.logMessages.map((message, index) => (
                    <p key={index}>{message}</p>
                ))}
            </div>
        </div>
    );
};

export default CombatLog;