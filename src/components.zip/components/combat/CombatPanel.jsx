// src/components/combat/CombatPanel.jsx

import React, { useState, useEffect, useCallback } from 'react';
import { enemyTemplates } from '../../data/enemies';
import { spells } from '../../data/spells';

// Import de vos composants d'affichage
import InitiativePanel from './InitiativePanel';
import CombatEndPanel from './CombatEndPanel';
import PlayerTurnPanel from './PlayerTurnPanel';
import EnemyDisplay from './EnemyDisplay'; 

const rollDice = (diceString) => {
    if (!diceString || !diceString.includes('d')) return 0;
    const [num, size] = diceString.split('d').map(Number);
    let totalDamage = 0;
    for (let i = 0; i < num; i++) {
        totalDamage += Math.floor(Math.random() * size) + 1;
    }
    return totalDamage;
};

const CombatPanel = ({ playerCharacter, setPlayerCharacter, onCombatEnd, addCombatMessage, setCombatLog, encounterData, onPlayerCastSpell, onPlayerTakeDamage }) => {
    const [combatEnemies, setCombatEnemies] = useState([]);
    const [turnOrder, setTurnOrder] = useState([]);
    const [currentTurnIndex, setCurrentTurnIndex] = useState(0);
    const [combatPhase, setCombatPhase] = useState('initiative-roll');
    const [playerAction, setPlayerAction] = useState(null);
    const [actionTargets, setActionTargets] = useState([]);

    const handleNextTurn = useCallback(() => {
        const allEnemiesDefeated = combatEnemies.every(enemy => enemy.hp <= 0);
        if (allEnemiesDefeated) {
            setCombatPhase('end');
            addCombatMessage("Victoire ! Les ennemis sont vaincus.");
            return;
        }
        
        if (playerCharacter.currentHP <= 0) {
            setCombatPhase('end');
            addCombatMessage("Défaite... Tu as perdu connaissance.");
            return;
        }

        const nextIndex = (currentTurnIndex + 1) % turnOrder.length;
        setCurrentTurnIndex(nextIndex);
        setCombatPhase('turn');
    }, [currentTurnIndex, turnOrder, combatEnemies, addCombatMessage, playerCharacter.currentHP]);

    const enemyAttack = useCallback(() => {
        const currentTurnEntity = turnOrder[currentTurnIndex];
        const isAliveInState = combatEnemies.find(e => e.name === currentTurnEntity.name)?.hp > 0;
        if (!isAliveInState) {
            addCombatMessage(`${currentTurnEntity.name} est déjà vaincu et ne peut pas attaquer.`);
            handleNextTurn();
            return;
        }
        const enemyAttackRoll = Math.floor(Math.random() * 20) + 1;
        const playerAC = playerCharacter.ac; 
        if (enemyAttackRoll >= playerAC) {
            const damage = rollDice(currentTurnEntity.damageDice);
            // CORRECTION ICI : Utilisation de la prop du parent
            onPlayerTakeDamage(damage, `${currentTurnEntity.name} t'attaque et touche ! Il inflige ${damage} dégâts !`);
        } else {
            addCombatMessage(`${currentTurnEntity.name} t'attaque, mais rate son coup.`);
        }
        handleNextTurn();
    }, [addCombatMessage, handleNextTurn, onPlayerTakeDamage, playerCharacter.ac, turnOrder, currentTurnIndex, combatEnemies]);

    const castSpell = useCallback((spell, targets) => {
        if (spell.level > 0) {
            const spellUsedSuccessfully = onPlayerCastSpell(spell);
            if (!spellUsedSuccessfully) {
                setPlayerAction(null);
                setActionTargets([]);
                return;
            }
        }
        
        setCombatEnemies(prevEnemies => {
            let updatedEnemies = [...prevEnemies];
            const defeatedThisTurn = new Set();
            
            targets.forEach(target => {
                const enemyIndex = updatedEnemies.findIndex(e => e.name === target.name);
                if (enemyIndex !== -1 && updatedEnemies[enemyIndex].hp > 0) {
                    let damage = 0;
                    
                    if (spell.requiresAttackRoll) {
                        const spellAttackBonus = playerCharacter.proficiencyBonus + Math.floor((playerCharacter.stats.intelligence - 10) / 2);
                        const attackRoll = Math.floor(Math.random() * 20) + 1 + spellAttackBonus;
                        
                        if (attackRoll >= updatedEnemies[enemyIndex].ac) {
                            damage = rollDice(spell.damage.dice) + (spell.damage.bonus || 0);
                            updatedEnemies[enemyIndex].hp = Math.max(0, updatedEnemies[enemyIndex].hp - damage);
                            addCombatMessage(`Le sort "${spell.name}" touche ${target.name} (Jet d'attaque: ${attackRoll}) et inflige ${damage} dégâts de ${spell.damage.type} !`);
                        } else {
                            addCombatMessage(`Le sort "${spell.name}" rate ${target.name} (Jet d'attaque: ${attackRoll}).`);
                        }
                    } else {
                        damage = rollDice(spell.damage.dice) + (spell.damage.bonus || 0);
                        updatedEnemies[enemyIndex].hp = Math.max(0, updatedEnemies[enemyIndex].hp - damage);
                        addCombatMessage(`Le sort "${spell.name}" frappe ${target.name} et inflige ${damage} dégâts de ${spell.damage.type} !`);
                    }

                    if (updatedEnemies[enemyIndex].hp <= 0 && !defeatedThisTurn.has(updatedEnemies[enemyIndex].name)) {
                        addCombatMessage(`${updatedEnemies[enemyIndex].name} a été vaincu !`);
                        defeatedThisTurn.add(updatedEnemies[enemyIndex].name);
                    }
                }
            });
            return updatedEnemies;
        });

        setPlayerAction(null);
        setActionTargets([]);
        handleNextTurn();
    }, [playerCharacter, addCombatMessage, handleNextTurn, onPlayerCastSpell]);

    const handleTargetSelection = useCallback((enemy) => {
        setActionTargets(prevTargets => {
            const newTargets = [...prevTargets, enemy];
            return newTargets;
        });
    }, []);

    useEffect(() => {
        if (!playerAction || !actionTargets) {
            return;
        }
        const maxTargets = playerAction.projectiles || 1;
        if (actionTargets.length === maxTargets) {
            castSpell(playerAction, actionTargets);
        }
    }, [actionTargets, playerAction, castSpell]);

    useEffect(() => {
        const initialCombatEnemies = encounterData.flatMap(encounter => {
            const template = enemyTemplates[encounter.type];
            if (!template) {
                console.error(`Erreur: Template de monstre '${encounter.type}' non trouvé.`);
                return [];
            }
            return Array(encounter.count).fill(null).map((_, index) => ({
                ...template,
                name: `${template.name} ${index + 1}`
            }));
        });
        if (!initialCombatEnemies || initialCombatEnemies.length === 0) {
            console.error("Erreur: La liste d'ennemis est vide. Le combat se termine.");
            addCombatMessage("Erreur lors du chargement des ennemis. Le combat se termine.");
            setCombatPhase('end');
            return;
        }
        setCombatEnemies(initialCombatEnemies);
        addCombatMessage("Un combat commence !");
        const playerDexMod = Math.floor((playerCharacter.stats.dexterite - 10) / 2);
        const playerInitiative = Math.floor(Math.random() * 20) + 1 + playerDexMod;
        const playerWithInitiative = { ...playerCharacter, initiative: playerInitiative, type: 'player', ac: 10 };
        const enemiesWithInitiative = initialCombatEnemies.map(enemy => ({
            ...enemy,
            initiative: Math.floor(Math.random() * 20) + 1 + Math.floor((enemy.dex - 10) / 2),
            type: 'enemy'
        }));
        const order = [...enemiesWithInitiative, playerWithInitiative].sort((a, b) => b.initiative - a.initiative);
        setTurnOrder(order);
        order.forEach(entity => {
            addCombatMessage(`${entity.name} a lancé l'initiative et a obtenu ${entity.initiative}.`);
        });
    }, [encounterData, playerCharacter.stats.dexterite, addCombatMessage]);
    
    useEffect(() => {
        if (combatPhase === 'initiative-roll' || combatPhase === 'end' || !turnOrder.length) {
            return;
        }
        const currentTurnEntity = turnOrder[currentTurnIndex];
        const isPlayerTurn = currentTurnEntity.type === 'player';
        const entityInState = combatEnemies.find(e => e.name === currentTurnEntity.name);
        if (entityInState && entityInState.hp <= 0) {
            addCombatMessage(`${currentTurnEntity.name} est déjà vaincu. On passe au suivant.`);
            handleNextTurn();
            return;
        }
        if (combatPhase === 'turn') {
            if (isPlayerTurn) {
                setCombatPhase('player-action');
                addCombatMessage("C'est ton tour !");
            } else {
                addCombatMessage(`C'est le tour de ${currentTurnEntity.name}...`);
                const timer = setTimeout(() => {
                    enemyAttack();
                }, 1500);
                return () => clearTimeout(timer);
            }
        }
    }, [currentTurnIndex, combatPhase, turnOrder, addCombatMessage, enemyAttack, combatEnemies]);
    
    return (
        <div>
            <EnemyDisplay
                combatEnemies={combatEnemies}
                onSelectTarget={playerAction ? handleTargetSelection : null}
                selectedTargets={actionTargets}
            />
            {combatPhase === 'initiative-roll' && (
                <InitiativePanel onStartCombat={() => setCombatPhase('turn')} />
            )}
            {combatPhase === 'end' && (
                <CombatEndPanel onContinue={() => {
                    setCombatLog([]); 
                    onCombatEnd(); 
                }} />
            )}
            {combatPhase === 'player-action' && (
                <PlayerTurnPanel
                    playerCharacter={playerCharacter}
                    onSelectSpell={setPlayerAction}
                    onPassTurn={() => { setPlayerAction(null); handleNextTurn(); }}
                    selectedSpell={playerAction}
                    selectedTargets={actionTargets}
                />
            )}
            {combatPhase === 'turn' && (
                <p>Le combat est en cours...</p>
            )}
        </div>
    );
};

export default CombatPanel;