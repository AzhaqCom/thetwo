import React from 'react';

const CombatEndPanel = ({ onContinue }) => {
    return (
        <div>
            <h3>Combat terminé !</h3>
            <button onClick={onContinue}>Continuer l'aventure</button>
        </div>
    );
};

export default CombatEndPanel;