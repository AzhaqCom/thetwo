// src/components/combat/PlayerTurnPanel.jsx

import React from 'react';
import { spells } from '../../data/spells';

const PlayerTurnPanel = ({ playerCharacter, onSelectSpell, onPassTurn, selectedSpell, selectedTargets }) => {
    // IMPORTANT : On ajoute selectedTargets aux props !
    // console.log("PlayerTurnPanel : selectedTargets mis à jour ->", selectedTargets);

    // Si un sort est sélectionné, on demande au joueur de choisir une cible.
    if (selectedSpell) {
        return (
            <div>
                {/* On utilise la longueur du tableau selectedTargets + 1 pour afficher le numéro de la cible actuelle */}
                <p>Choisis la cible n°{selectedTargets.length + 1} de ton sort ({selectedTargets.length + 1}/{selectedSpell.projectiles || 1}) :</p>
                <button onClick={() => { onSelectSpell(null); }}>Annuler le sort</button>
            </div>
        );
    }

    // Sinon, on affiche la liste des sorts
    const offensiveSpells = [...playerCharacter.spellcasting.cantrips, ...playerCharacter.spellcasting.preparedSpells]
        .map(spellName => spells[spellName])
        .filter(spell => spell && spell.damage);
    
    return (
        <div>
            <p>C'est ton tour ! Quel sort veux-tu lancer ?</p>
            {offensiveSpells.map(spell => (
                <button key={spell.name} onClick={() => onSelectSpell(spell)}>
                    {spell.name}
                    {spell.level > 0 && ` (Niv. ${spell.level})`}
                </button>
            ))}
            <button onClick={onPassTurn}>Passer le tour</button>
        </div>
    );
};

export default PlayerTurnPanel;