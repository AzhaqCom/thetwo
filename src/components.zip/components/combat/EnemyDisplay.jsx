// src/components/combat/EnemyDisplay.jsx

import React from 'react';

const EnemyDisplay = ({ combatEnemies, onSelectTarget, selectedTargets }) => {
    if (!combatEnemies || combatEnemies.length === 0) {
        return null;
    }

    const isTargetable = (enemy) => {
        // Un ennemi est cliquable s'il est encore en vie.
        // On ne vérifie plus s'il est déjà dans selectedTargets pour permettre le ciblage multiple.
        return enemy.hp > 0;
    };

    return (
        <div style={{ display: 'flex', justifyContent: 'center', gap: '20px', margin: '20px 0' }}>
            {combatEnemies.map(enemy => (
                <div
                    key={enemy.name}
                    style={{
                        textAlign: 'center',
                        cursor: onSelectTarget && isTargetable(enemy) ? 'pointer' : 'default',
                        opacity: enemy.hp <= 0 ? 0.5 : 1,
                        border: selectedTargets.some(target => target.name === enemy.name) ? '2px solid green' : '2px solid transparent',
                        transition: 'border 0.2s ease-in-out'
                    }}
                    onClick={() => {
                        // On vérifie que onSelectTarget existe ET que la cible est valide avant d'appeler la fonction.
                        if (onSelectTarget && isTargetable(enemy)) {
                            onSelectTarget(enemy);
                        }
                    }}
                >
                    <img
                        src={enemy.image}
                        alt={enemy.name}
                        style={{ width: '100px', height: '100px', borderRadius: '5px' }}
                    />
                    <h4>{enemy.name}</h4>
                    <p>PV: {Math.max(0, enemy.hp)}</p>
                </div>
            ))}
        </div>
    );
};

export default EnemyDisplay;